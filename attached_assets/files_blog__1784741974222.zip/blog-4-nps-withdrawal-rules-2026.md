# NPS Withdrawal Rules 2026: The New 80:20 Rule, Exit at 15 Years, and Staying Invested Till 85 — Fully Explained

**Meta Title:** NPS Withdrawal Rules 2026: New 80:20 Rule, ₹8 Lakh Full Withdrawal, Deferral Till 85 | RetirePro
**Meta Description:** PFRDA has overhauled NPS exits. Understand the new 80% lump sum rule, corpus slabs, 15-year exit, SLW, staying invested till 85, premature exit rules and the tax fine print — explained simply.
**Slug:** /blog/nps-withdrawal-rules-2026
**Target Keywords:** NPS withdrawal rules 2026, NPS 80:20 rule, NPS lump sum withdrawal, NPS exit rules, NPS stay invested till 85, NPS systematic lump sum withdrawal

---

If you last read about NPS a couple of years ago, forget most of what you knew about its exit rules. The Pension Fund Regulatory and Development Authority (PFRDA) has overhauled withdrawals so substantially that NPS in 2026 is, at exit, almost a different product — dramatically more flexible, more liquid, and more useful as a genuine retirement vehicle.

This guide explains every rule change in plain language — what the old rule was, what the new rule is, and what it means for your money — including the tax fine print that headlines conveniently skip.

*(Rules described are as reported for non-government/All-Citizens subscribers as of mid-2026; government-sector rules differ in places, and tax treatment of the newest provisions may evolve. Verify specifics with NPS Trust/your POP before acting.)*

## First, a 60-Second Refresher: How NPS Exit Works

NPS is a retirement account you fill during your working years. At exit, your accumulated pension wealth is split two ways:
- A **lump sum** you take in hand (fully or in instalments), and
- A mandatory **annuity** — a portion used to buy an insurance product that pays you monthly pension for life.

Every rule below is essentially about three questions: *how much* lump sum you can take, *when* you can take it, and *how long* you can keep the money growing instead.

## Change 1: The Headline — 80% Lump Sum, Only 20% Annuity (The "80:20 Rule")

**Old rule:** At normal exit, you could take at most **60%** of your corpus as lump sum; **40%** had to buy an annuity.

**New rule:** Non-government subscribers can now withdraw **up to 80% as lump sum, with only 20% going to the mandatory annuity.**

**Why this is huge:** The 40% annuity mandate was NPS's most criticised feature — it forced a large chunk of your life savings into low-yield annuities at whatever rates prevailed on your retirement day. Cutting the mandate to 20% hands you back discretion over a much larger share of your own money — for healthcare buffers, debt clearance, family needs, or reinvestment at better yields than annuities offer.

**⚠️ The tax fine print nobody puts in the headline:** Under current income-tax law, the exemption under Section 10(12A) covers **60%** of the corpus. Until the tax law is explicitly amended, the *additional* 20% you withdraw under the new 80% option may be **taxable**. And annuity income has always been taxable as ordinary income. So the regulator's 80% and the taxman's 60% are not yet the same number — anyone planning an 80% withdrawal must plan for tax on the extra slice or wait for clarity.

## Change 2: Corpus Slabs — Small Corpuses Get Even More Freedom

Exits are now tiered by corpus size rather than one-size-fits-all:

| Accumulated Corpus at Exit | What You Can Do |
|---|---|
| **Up to ₹8 lakh** | Withdraw **100%** as lump sum — no annuity forced (raised from the earlier ₹5 lakh threshold) |
| **₹8–12 lakh** | Take up to **₹6 lakh / up to 80%** as lump sum; balance via annuity or phased payout |
| **Above ₹12 lakh** | The standard **80:20** rule applies |

The logic: forcing a ₹6-lakh corpus into a 20% annuity would buy a pension of a few hundred rupees a month — pointless. Small savers now get clean, full payouts.

## Change 3: Exit After 15 Years — No More Waiting for 60

**Old rule:** Normal exit for private subscribers essentially meant waiting until age 60/superannuation.

**New rule:** Normal exit is now allowed after **15 years of participation or age 60, whichever comes first**.

**What it means:** A 28-year-old who joins NPS can make a *normal* exit — with the full favourable lump-sum rules — at 43. NPS suddenly becomes relevant to FIRE aspirants and early retirees, not just traditional 60-year retirements. (The older 5-year lock-in framing has also been dispensed with in the revised structure.)

## Change 4: Stay Invested and Defer Till Age 85

**Old rule:** Maximum age to remain invested / defer withdrawal was 75 (entry capped at 70).

**New rule:** You can now **stay invested in NPS until age 85**, and defer your lump-sum withdrawal and annuity purchase up to that age. New accounts can be opened up to age 70, and late joiners (post-60) benefit from removed vesting friction.

**Why this matters more than it sounds:** You are *not* forced to liquidate at 60. If you have other income in your 60s — rent, part-time work, a spouse's pension — you can leave the NPS corpus compounding tax-deferred for another 10–25 years and exit when *you* choose, ideally not in the middle of a market crash. Sequencing your withdrawals across sources is one of the most powerful (and most ignored) retirement levers, and this change enables it.

## Change 5: Systematic Lump Sum Withdrawal (SLW) — a "Reverse SIP"

Instead of taking your entire eligible lump sum on day one, you can instruct NPS to pay it out in **periodic instalments** — monthly, quarterly, annually — while the balance stays invested and keeps earning, with the instalment window running up to age 75+ under the deferral rules.

Think of it as the mirror image of a SIP: you spent 30 years drip-feeding money *in*; SLW lets you drip-feed it *out*, smoothing your income and avoiding the classic mistake of parking a huge lump sum in a savings account earning 3%.

## Change 6: Premature Exit — Still Deliberately Harsh

Leaving *before* qualifying for normal exit remains punitive by design: if your corpus exceeds ₹5 lakh at premature exit, **at least 80% must buy an annuity** and only ~20% comes to you as lump sum (corpus ≤ ₹5 lakh can be taken in full). Partial withdrawals during the accumulation phase (up to 25% of your own contributions, for specified purposes like education, marriage, illness, house) continue as a separate, limited facility.

The message from the regulator is consistent: flexibility at retirement — yes; raiding the nest egg early — no.

## What Should You Actually Do With These Rules? (Strategy, Not Just Rules)

1. **Don't reflexively take the maximum lump sum.** 80% *available* doesn't mean 80% *advisable* — especially while the tax treatment of the extra 20% is unsettled. The annuity, for all its flaws, is longevity insurance: it pays even if you live to 100.
2. **Use deferral as sequencing power.** If other income covers your 60s, letting the corpus compound to 70+ can dramatically increase both your lump sum and your eventual annuity.
3. **Use SLW instead of a savings-account dump.** Phased withdrawal keeps the unwithdrawn balance working.
4. **Match the choice to your corpus slab.** Below ₹8 lakh, take the clean exit and redeploy deliberately. Above ₹12 lakh, the 80:20 split plus SLW plus deferral gives you a genuine toolkit — use it as one.
5. **Decide using your full retirement picture — not NPS in isolation.** Whether to annuitise 20% or 40%, exit at 60 or defer to 70, take lump sum or SLW — none of these questions can be answered without knowing your **total required corpus, your expenses, your inflation outlook, and your life expectancy**.

## The Bigger Point: Flexible Rules Don't Fix an Uncalculated Retirement

Here's the trap these reforms create: more flexibility means more decisions, and more decisions made on gut feel mean more ways to go wrong. An 80% lump sum in the hands of someone who has never calculated their 30-year requirement is not freedom — it's rope.

The order of operations for a smart retiree is: **first know your number, then choose your withdrawal strategy.** How much do you need per month, inflated to your retirement date? For how many years — to 85? 90? What must your corpus be, and what will NPS + EPF + investments actually deliver? Only against those answers do questions like "60% or 80% lump sum?" and "exit at 60 or defer?" have rational answers.

[RetirePro.in](https://retirepro.in) exists for exactly this: a free, no-login retirement calculator built for India where **every assumption is yours** — expenses, inflation, life expectancy, pre- and post-retirement returns are all visible, editable, and saveable. Model your NPS corpus as part of the whole picture, see year-wise projections, test scenarios (exit at 60 vs deferral to 70 changes the math dramatically), and know — don't assume — whether you're on track. The new NPS rules give you the steering wheel; RetirePro gives you the map.

## FAQ

**What is the new 80:20 rule in NPS?**
Non-government subscribers with a corpus above ₹12 lakh can now take up to 80% of their NPS corpus as a lump sum at normal exit, with a minimum of 20% used to purchase an annuity — versus the earlier 60:40 split.

**Is the 80% NPS lump sum fully tax-free?**
Not yet clearly. The existing income-tax exemption covers 60% of the corpus; the additional 20% permitted by the new PFRDA rules may be taxable until the tax law is amended. Plan conservatively and check the latest position before exiting.

**Can I withdraw my full NPS corpus?**
Yes, if your accumulated corpus at normal exit is within the small-corpus threshold (raised to ₹8 lakh), you can withdraw 100% with no annuity requirement. Premature exits with corpus ≤ ₹5 lakh can also be taken in full.

**Can I stay invested in NPS after 60?**
Yes — you can now remain invested and defer withdrawal/annuity purchase up to age 85, letting the corpus continue compounding.

**What is Systematic Lump Sum Withdrawal (SLW) in NPS?**
Instead of taking your eligible lump sum at once, SLW pays it out in periodic instalments (like a reverse SIP) while the remaining balance stays invested.

**When can I exit NPS without penalty?**
Normal exit is now available after 15 years of participation or at age 60/superannuation, whichever comes first — with the full favourable lump-sum rules.
